(() => {
  const section = document.getElementById('community-notes');
  if (!section) return;
  const projectUrl = (document.querySelector('meta[name="comments-supabase-url"]')?.content || '').replace(/\/$/, '');
  const publishableKey = document.querySelector('meta[name="comments-publishable-key"]')?.content || '';
  const endpoint = projectUrl ? `${projectUrl}/functions/v1/community-comments` : '';
  const list = document.getElementById('community-list');
  const form = document.getElementById('community-form');
  const status = document.getElementById('community-status');
  const part = section.dataset.partNumber;
  if (!endpoint || !publishableKey) {
    list.textContent = 'The comments service has not been configured yet.';
    form.querySelectorAll('input, select, textarea, button').forEach(control => { control.disabled = true; });
    status.textContent = 'Comments will be available after the service is deployed and the site is rebuilt.';
    return;
  }

  const categories = ['Tip', 'Warning', 'Problem', 'Fix', 'Question', 'Solution'];
  const headers = { apikey: publishableKey, 'Content-Type': 'application/json' };
  const make = (tag, cls, value) => { const el = document.createElement(tag); if (cls) el.className = cls; if (value) el.textContent = value; return el; };
  async function loadNotes() {
    list.textContent = 'Loading community notes…';
    try {
      const response = await fetch(`${endpoint}?part_number=${encodeURIComponent(part)}`, { headers });
      if (!response.ok) throw new Error('Could not load notes.');
      const notes = await response.json();
      list.replaceChildren();
      if (!notes.length) { list.textContent = 'No approved notes yet. Contributions appear here after review.'; return; }
      for (const note of notes) {
        const card = make('article', 'community-item');
        const heading = make('strong', '', `${note.category} · ${note.author}`);
        const date = make('small', '', `  ${new Date(note.created_at).toLocaleDateString()}`);
        const body = make('p', '', note.body);
        const report = make('button', 'report-button', 'Report');
        report.type = 'button';
        report.addEventListener('click', async () => {
          report.disabled = true;
          try {
            const r = await fetch(`${endpoint}/report`, { method: 'POST', headers, body: JSON.stringify({ comment_id: note.id }) });
            report.textContent = r.ok ? 'Reported' : 'Try again later';
          } catch { report.textContent = 'Try again later'; }
        });
        card.append(heading, date, body, report); list.append(card);
      }
    } catch { list.textContent = 'Community notes are temporarily unavailable.'; }
  }
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(form));
    status.textContent = 'Sending for review…';
    try {
      const response = await fetch(endpoint, {
        method: 'POST', headers,
        body: JSON.stringify({ ...values, part_number: part })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not submit.');
      form.reset(); status.textContent = 'Thanks. Your note is pending moderator review.';
    } catch (error) { status.textContent = error.message || 'Could not submit. Please try again later.'; }
  });
  loadNotes();
})();
